import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
  } catch (_) {
    // A configuração nativa do Firebase (google-services.json/GoogleService-Info.plist)
    // é adicionada quando o projeto real for conectado. A interface continua abrindo
    // para permitir testes locais sem credenciais.
  }
  runApp(const BatConnectApp());
}

const orange = Color(0xFFF57C00);
const dark = Color(0xFF15171A);
const soft = Color(0xFFF6F7F9);
const modernBuildId = 'BAT_CONNECT_MODERNA_1.5.3_BUILD_27_FONTE_UNICA_MODERNA';

class BatConnectApp extends StatelessWidget {
  const BatConnectApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Bat Connect',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: orange, brightness: Brightness.light),
      scaffoldBackgroundColor: soft,
      cardTheme: const CardThemeData(elevation: 0, margin: EdgeInsets.zero),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
    ),
    home: const WelcomePage(),
  );
}

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: dark,
    body: SafeArea(
      child: Column(children: [
        Expanded(
          flex: 5,
          child: Stack(fit: StackFit.expand, children: [
            Image.asset('assets/bat_connect_logo.png', fit: BoxFit.cover, alignment: Alignment.center),
            const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter,end: Alignment.bottomCenter,colors:[Colors.transparent,Color(0x3315171A),dark]))),
            Positioned(left:20,right:20,bottom:18,child:Container(
              padding:const EdgeInsets.symmetric(horizontal:16,vertical:10),
              decoration:BoxDecoration(color:dark.withValues(alpha:.88),borderRadius:BorderRadius.circular(18),border:Border.all(color:orange.withValues(alpha:.7))),
              child:const Row(children:[Icon(Icons.directions_car_rounded,color:orange),SizedBox(width:10),Expanded(child:Text('BAT CONNECT • OPERAÇÃO DE ESCOLTA',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900,letterSpacing:.5)))])
            )),
          ]),
        ),
        Expanded(
          flex: 4,
          child: Container(
            width:double.infinity,
            padding:const EdgeInsets.fromLTRB(20,18,20,16),
            decoration:const BoxDecoration(color:Color(0xFFF6F7F9),borderRadius:BorderRadius.vertical(top:Radius.circular(32))),
            child:ListView(children:[
              const Text('Entrar no Bat Connect',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900,color:dark)),
              const SizedBox(height:4),const Text('Selecione seu acesso',style:TextStyle(color:Colors.black54)),const SizedBox(height:16),
              Row(children:[
                Expanded(child:_access(context,'Batedor',Icons.directions_car_rounded,()=>const HomePage(company:false))),const SizedBox(width:10),
                Expanded(child:_access(context,'Empresa',Icons.business_rounded,()=>const HomePage(company:true))),
              ]),
              const SizedBox(height:10),
              Row(children:[
                Expanded(child:_access(context,'Escolta',Icons.groups_rounded,()=>const AdminEmpresaEscoltaPage())),const SizedBox(width:10),
                Expanded(child:_access(context,'Admin',Icons.admin_panel_settings_rounded,()=>const AdminPage())),
              ]),
              const SizedBox(height:12),
              TextButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const HelpPage())),icon:const Icon(Icons.support_agent_rounded),label:const Text('Ajuda e suporte')),
              const Text('v1.5.3 • BUILD 27 • FONTE ÚNICA MODERNA',textAlign:TextAlign.center,style:TextStyle(fontSize:10,fontWeight:FontWeight.w800,color:Colors.black45)),
            ]),
          ),
        )
      ]),
    ),
  );

  Widget _access(BuildContext c,String title,IconData icon,Widget Function() page)=>Material(
    color:Colors.white,borderRadius:BorderRadius.circular(20),
    child:InkWell(borderRadius:BorderRadius.circular(20),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>page())),child:Padding(
      padding:const EdgeInsets.symmetric(horizontal:12,vertical:15),
      child:Row(children:[Container(width:40,height:40,decoration:BoxDecoration(color:orange.withValues(alpha:.12),borderRadius:BorderRadius.circular(13)),child:Icon(icon,color:orange)),const SizedBox(width:9),Expanded(child:Text(title,style:const TextStyle(fontWeight:FontWeight.w900,color:dark))),const Icon(Icons.arrow_forward_ios_rounded,size:14,color:Colors.black38)]),
    )),
  );
}

class SelfieGatePage extends StatefulWidget {
  const SelfieGatePage({super.key, required this.role, required this.destination});
  final String role; final Widget destination;
  @override State<SelfieGatePage> createState()=>_SelfieGatePageState();
}
class _SelfieGatePageState extends State<SelfieGatePage>{
  final picker=ImagePicker(); XFile? selfie; bool consent=false;
  Future<void> capture() async { final x=await picker.pickImage(source:ImageSource.camera,preferredCameraDevice:CameraDevice.front,imageQuality:80,maxWidth:1200); if(x!=null)setState(()=>selfie=x); }
  void enter(){ if(selfie==null||!consent)return; Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>widget.destination)); }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(widget.role,style:const TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(22),children:[
    const Icon(Icons.face_retouching_natural,color:orange,size:72),const SizedBox(height:12),const Text('Selfie para iniciar a operação',textAlign:TextAlign.center,style:TextStyle(fontSize:23,fontWeight:FontWeight.w900)),const SizedBox(height:8),
    const Text('Exclusivo para o batedor: tire uma selfie antes de iniciar esta operação.',textAlign:TextAlign.center,style:TextStyle(color:Colors.black54)),const SizedBox(height:20),
    if(selfie!=null)ClipRRect(borderRadius:BorderRadius.circular(24),child:Image.file(File(selfie!.path),height:260,fit:BoxFit.cover)) else Container(height:220,decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(24)),child:const Center(child:Icon(Icons.person_pin_circle_outlined,size:80,color:Colors.black26))),
    const SizedBox(height:14),SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:capture,icon:const Icon(Icons.camera_alt),label:Text(selfie==null?'Tirar selfie':'Tirar outra selfie'))),
    CheckboxListTile(contentPadding:EdgeInsets.zero,value:consent,onChanged:(v)=>setState(()=>consent=v??false),title:const Text('Confirmo o uso desta selfie para validação do início da operação.')),
    SizedBox(width:double.infinity,child:FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:orange,padding:const EdgeInsets.all(16)),onPressed:selfie!=null&&consent?enter:null,icon:const Icon(Icons.verified_user),label:const Text('Confirmar selfie e iniciar'))),
    const SizedBox(height:12),const Text('Nesta build a captura e a trava de entrada estão ativas. A comparação biométrica com uma selfie previamente cadastrada exige backend/serviço de reconhecimento facial e não é simulada como se já estivesse validando identidade.',style:TextStyle(color:Colors.black54,fontSize:12))
  ]));
}

class HomePage extends StatefulWidget { const HomePage({super.key,required this.company}); final bool company; @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage>{
  int tab=0; bool online=true;
  @override Widget build(BuildContext context){
    final pages=widget.company?[companyHome(),const OperationsPage(company:true),const WalletPage(),const ProfilePage()]:[providerHome(),const OperationsPage(company:false),const WalletPage(),const ProfilePage()];
    return Scaffold(
      appBar:AppBar(backgroundColor:soft,title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(widget.company?'Olá, Empresa':'Olá, Batedor',style:const TextStyle(fontSize:13,color:Colors.black54)),const Text('Bat Connect',style:TextStyle(fontWeight:FontWeight.w900))]),actions:[IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const HelpPage())),icon:const Icon(Icons.support_agent_rounded)),const SizedBox(width:8)]),
      body:pages[tab],
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home_rounded),label:'Início'),NavigationDestination(icon:Icon(Icons.route_outlined),selectedIcon:Icon(Icons.route),label:'Operações'),NavigationDestination(icon:Icon(Icons.account_balance_wallet_outlined),selectedIcon:Icon(Icons.account_balance_wallet),label:'Bat Collect'),NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Perfil')]),
    );
  }
  Widget companyHome()=>ListView(padding:const EdgeInsets.all(18),children:[
    _modernCarBanner(),const SizedBox(height:16),
    _hero('Sua operação em um só lugar','Publique, monte a equipe e acompanhe em tempo real.',Icons.route_rounded),const SizedBox(height:18),
    FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:orange,padding:const EdgeInsets.all(17)),onPressed:()=>showModalBottomSheet(context:context,isScrollControlled:true,builder:(_)=>const RequestSheet()),icon:const Icon(Icons.add_rounded),label:const Text('Nova solicitação de escolta')),
    const SizedBox(height:10),
    OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AdminEmpresaEscoltaPage())),icon:const Icon(Icons.radar_outlined,color:orange),label:const Text('Painel da Empresa de Escolta')),
    const SizedBox(height:24),const _Title('Operação em andamento'),const SizedBox(height:10),
    _operationCard('Arujá, SP','Guarulhos, SP','Equipe: 3 batedores','EM ROTA'),const SizedBox(height:22),const _Title('Atalhos'),const SizedBox(height:10),_shortcuts(),
  ]);
  Widget providerHome()=>ListView(padding:const EdgeInsets.all(18),children:[
    _modernCarBanner(),const SizedBox(height:16),
    Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:dark,borderRadius:BorderRadius.circular(26),boxShadow:[BoxShadow(color:Colors.black.withValues(alpha:.08),blurRadius:18,offset:const Offset(0,8))]),child:Row(children:[Container(width:52,height:52,decoration:BoxDecoration(color:online?orange:Colors.white12,borderRadius:BorderRadius.circular(17)),child:Icon(online?Icons.directions_car_filled_rounded:Icons.power_settings_new_rounded,color:Colors.white,size:29)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(online?'BATEDOR ONLINE':'BATEDOR OFFLINE',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:19,color:Colors.white)),const SizedBox(height:3),Text(online?'Disponível para novas operações':'Ative para receber chamadas',style:const TextStyle(color:Colors.white70))])),Switch(activeThumbColor:orange,value:online,onChanged:(v)=>setState(()=>online=v)))),
    const SizedBox(height:18),_hero('Chamadas próximas','Veja origem, destino e detalhes antes de aceitar.',Icons.notifications_active_rounded),const SizedBox(height:22),const _Title('Solicitação disponível'),const SizedBox(height:10),
    _operationCard('Arujá, SP','Campinas, SP','Saída agendada • 05:00','DISPONÍVEL'),const SizedBox(height:10),OutlinedButton.icon(onPressed:online?()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const IncomingCallPage())):null,icon:const Icon(Icons.notifications_active),label:const Text('Testar tela de chamada')),const SizedBox(height:12),Row(children:[Expanded(child:OutlinedButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Operação recusada no modo de teste.'))),child:const Text('Recusar'))),const SizedBox(width:10),Expanded(child:FilledButton(style:FilledButton.styleFrom(backgroundColor:orange),onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Operação aceita no modo de teste. Abra Minhas Operações para continuar.'))),child:const Text('Aceitar')))]),const SizedBox(height:22),_shortcuts(),
  ]);
  Widget _modernCarBanner()=>Container(height:210,decoration:BoxDecoration(borderRadius:BorderRadius.circular(28),boxShadow:[BoxShadow(color:Colors.black.withValues(alpha:.10),blurRadius:20,offset:const Offset(0,8))]),child:ClipRRect(borderRadius:BorderRadius.circular(28),child:Image.asset('assets/bat_connect_logo.png',width:double.infinity,height:210,fit:BoxFit.cover,alignment:Alignment.center)));
  Widget _hero(String a,String b,IconData i)=>Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(color:dark,borderRadius:BorderRadius.circular(26)),child:Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:6),Text(b,style:const TextStyle(color:Colors.white70))])),Icon(i,color:orange,size:50)]));
  Widget _operationCard(String a,String b,String sub,String status)=>Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(22)),child:Column(children:[Row(children:[const Icon(Icons.radio_button_checked,color:orange,size:18),const SizedBox(width:10),Expanded(child:Text(a,style:const TextStyle(fontWeight:FontWeight.w700))),_pill(status)]),Container(margin:const EdgeInsets.only(left:8),height:24,width:2,color:Colors.black12),Row(children:[const Icon(Icons.location_on_rounded,color:dark,size:20),const SizedBox(width:10),Expanded(child:Text(b,style:const TextStyle(fontWeight:FontWeight.w700)))]),const Divider(height:28),Row(children:[const Icon(Icons.groups_2_outlined,size:19),const SizedBox(width:8),Text(sub,style:const TextStyle(color:Colors.black54)),const Spacer(),const Icon(Icons.chevron_right)])]));
  Widget _pill(String s)=>Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:5),decoration:BoxDecoration(color:orange.withValues(alpha:.12),borderRadius:BorderRadius.circular(20)),child:Text(s,style:const TextStyle(color:orange,fontSize:10,fontWeight:FontWeight.w900)));
  Widget _shortcuts()=>Wrap(spacing:10,runSpacing:10,children:[_chip(Icons.map_outlined,'Mapa',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const NavigationPage()))),_chip(Icons.chat_bubble_outline,'Chat',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ChatPage()))),_chip(Icons.badge_outlined,'Documentos',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const DocumentsPage()))),_chip(Icons.history,'Histórico',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const HistoryPage()))),_chip(Icons.report_problem_outlined,'Sinistro',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const IncidentPage()))) ]);
  Widget _chip(IconData i,String s,[VoidCallback? action])=>ActionChip(onPressed:action??(){},avatar:Icon(i,color:orange,size:19),label:Text(s));
}

class _Title extends StatelessWidget{const _Title(this.t);final String t;@override Widget build(BuildContext c)=>Text(t,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900));}

class RequestSheet extends StatefulWidget{const RequestSheet({super.key});@override State<RequestSheet> createState()=>_RequestSheetState();}
class _RequestSheetState extends State<RequestSheet>{String pay='PIX';String timing='Agora';DateTime? scheduled;@override Widget build(BuildContext c)=>Padding(padding:EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(c).viewInsets.bottom+24),child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[const Expanded(child:Text('Nova solicitação',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900))),IconButton(onPressed:()=>Navigator.pop(c),icon:const Icon(Icons.close))]),const SizedBox(height:14),const TextField(decoration:InputDecoration(labelText:'Origem',prefixIcon:Icon(Icons.trip_origin))),const SizedBox(height:10),const TextField(decoration:InputDecoration(labelText:'Destino',prefixIcon:Icon(Icons.location_on_outlined))),const SizedBox(height:10),const TextField(keyboardType:TextInputType.number,decoration:InputDecoration(labelText:'Quantidade de batedores',prefixIcon:Icon(Icons.groups_outlined))),const SizedBox(height:16),const Text('Quando?',style:TextStyle(fontWeight:FontWeight.w800)),SegmentedButton<String>(segments:const [ButtonSegment(value:'Agora',label:Text('Agora'),icon:Icon(Icons.flash_on)),ButtonSegment(value:'Agendar',label:Text('Agendar'),icon:Icon(Icons.schedule))],selected:{timing},onSelectionChanged:(v)=>setState(()=>timing=v.first)),if(timing=='Agendar') Padding(padding:const EdgeInsets.only(top:10),child:ListTile(tileColor:Colors.white,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16)),leading:const Icon(Icons.event,color:orange),title:Text(scheduled==null?'Escolher data e horário':'${scheduled!.day.toString().padLeft(2,'0')}/${scheduled!.month.toString().padLeft(2,'0')}/${scheduled!.year} • ${scheduled!.hour.toString().padLeft(2,'0')}:${scheduled!.minute.toString().padLeft(2,'0')}'),onTap:()async{final d=await showDatePicker(context:c,firstDate:DateTime.now(),lastDate:DateTime.now().add(const Duration(days:365)));if(d==null||!c.mounted)return;final t=await showTimePicker(context:c,initialTime:TimeOfDay.now());if(t!=null)setState(()=>scheduled=DateTime(d.year,d.month,d.day,t.hour,t.minute));})),const SizedBox(height:16),const Text('Pagamento',style:TextStyle(fontWeight:FontWeight.w800)),const Text('Somente PIX e boleto.',style:TextStyle(color:Colors.black54)),RadioListTile(value:'PIX',groupValue:pay,onChanged:(v)=>setState(()=>pay=v!),title:const Text('PIX')),RadioListTile(value:'Boleto',groupValue:pay,onChanged:(v)=>setState(()=>pay=v!),title:const Text('Boleto')),const SizedBox(height:8),SizedBox(width:double.infinity,child:FilledButton(style:FilledButton.styleFrom(backgroundColor:orange,padding:const EdgeInsets.all(16)),onPressed:()=>Navigator.pop(c),child:Text(timing=='Agora'?'Publicar agora':'Agendar solicitação')))]))));}}

class OperationsPage extends StatelessWidget{
  const OperationsPage({super.key,required this.company}); final bool company;
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(18),children:[
    const _Title('Minhas operações'),const SizedBox(height:12),
    _item(c,'Em andamento','Arujá → Guarulhos','Check-in confirmado',false),const SizedBox(height:10),
    _item(c,'Agendada','Guarulhos → Campinas','Amanhã • 05:00',true),const SizedBox(height:10),
    _item(c,'Concluída','São Paulo → Arujá','Entrega validada',false)
  ]);
  Widget _item(BuildContext c,String s,String r,String x,bool canStart)=>InkWell(
    borderRadius:BorderRadius.circular(20),
    onTap:canStart?()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>OperationStartPage(company:company,route:r))):null,
    child:Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(20)),child:Row(children:[CircleAvatar(backgroundColor:orange.withValues(alpha:.12),child:const Icon(Icons.directions_car,color:orange)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(s,style:const TextStyle(fontWeight:FontWeight.w900)),Text(r),Text(x,style:const TextStyle(color:Colors.black54,fontSize:12))])),if(canStart)const Icon(Icons.chevron_right)])));
}

class OperationStartPage extends StatelessWidget{
  const OperationStartPage({super.key,required this.company,required this.route}); final bool company; final String route;
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Detalhes da operação',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(20),children:[
    ClipRRect(borderRadius:BorderRadius.circular(24),child:Image.asset('assets/bat_connect_logo.png',height:160,fit:BoxFit.cover)),const SizedBox(height:18),
    Text(route,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:8),
    Text(company?'A empresa acompanha o status da equipe. Não é exigida selfie para empresa ou administrador.':'Antes de iniciar o trabalho, o batedor deve confirmar presença com uma selfie.',style:const TextStyle(color:Colors.black54)),const SizedBox(height:22),
    if(company) FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:orange,padding:const EdgeInsets.all(16)),onPressed:()=>ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Acompanhamento da operação aberto.'))),icon:const Icon(Icons.visibility_outlined),label:const Text('Acompanhar operação'))
    else FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:orange,padding:const EdgeInsets.all(16)),onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>SelfieGatePage(role:'Batedor • início da operação',destination:const NavigationPage()))),icon:const Icon(Icons.camera_front_outlined),label:const Text('Tirar selfie e iniciar operação')),
  ]));
}

class HelpPage extends StatelessWidget{const HelpPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Ajuda e Suporte',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(18),children:[
  Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:dark,borderRadius:BorderRadius.circular(24)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(Icons.support_agent,color:orange,size:38),SizedBox(height:10),Text('Como podemos ajudar?',style:TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.w900)),Text('Escolha uma mensagem pronta para registrar o assunto com clareza.',style:TextStyle(color:Colors.white70))])),
  const SizedBox(height:20),const _Title('Mensagens rápidas'),const SizedBox(height:8),
  ...['Estou com problema para entrar na minha conta.','Não estou recebendo chamadas de novas operações.','Aceitei uma operação, mas ela não aparece em Minhas Operações.','Estou com problema no check-in da operação.','O mapa ou a localização em tempo real não está atualizando.','Não consigo enviar a foto de entrega.','Minha operação foi concluída, mas o pagamento ainda não foi liberado.','Preciso de ajuda com meu PIX ou recebimento no Bat Collect.','Preciso atualizar minha CNH, credencial PRF ou documento do veículo.','Minha conta foi bloqueada temporariamente e preciso verificar o prazo de retorno.','Sou empresa e preciso de ajuda para publicar ou encerrar uma solicitação.','Minha equipe está completa, mas o status não foi atualizado.','Outro assunto — quero falar com o suporte.'].map((m)=>Card(margin:const EdgeInsets.only(bottom:8),child:ListTile(onTap:()=>_show(c,m),leading:const Icon(Icons.chat_bubble_outline,color:orange),title:Text(m),trailing:const Icon(Icons.chevron_right))),
  const SizedBox(height:12),const Text('Emergência na operação',style:TextStyle(fontWeight:FontWeight.w900,fontSize:17)),const SizedBox(height:5),const Text('Em situação de risco ou emergência, priorize os canais oficiais de emergência e segurança. O suporte do aplicativo é destinado a questões da plataforma e da operação registrada.',style:TextStyle(color:Colors.black54)),
]));void _show(BuildContext c,String m)=>showModalBottomSheet(context:c,builder:(_)=>Padding(padding:const EdgeInsets.all(22),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Mensagem para o suporte',style:TextStyle(fontWeight:FontWeight.w900,fontSize:20)),const SizedBox(height:12),Container(width:double.infinity,padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:soft,borderRadius:BorderRadius.circular(16)),child:Text(m)),const SizedBox(height:14),const Text('Nesta demonstração, o envio ao atendimento ainda não está conectado.',style:TextStyle(color:Colors.black54)),const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton(style:FilledButton.styleFrom(backgroundColor:orange),onPressed:()=>Navigator.pop(c),child:const Text('Entendi')))])));}


class AdminEmpresaEscoltaPage extends StatefulWidget { const AdminEmpresaEscoltaPage({super.key}); @override State<AdminEmpresaEscoltaPage> createState()=>_AdminEmpresaEscoltaPageState(); }
class _AdminEmpresaEscoltaPageState extends State<AdminEmpresaEscoltaPage>{
  final List<Map<String,String>> batedores=[
    {'nome':'João da Silva','status':'Em rota','local':'Arujá, SP','hora':'13:31'},
    {'nome':'Carlos Oliveira','status':'Online','local':'Guarulhos, SP','hora':'13:29'},
    {'nome':'Marcos Santos','status':'Em operação','local':'São Paulo, SP','hora':'13:25'},
  ];
  bool assinaturaAtiva=true;
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Admin Empresa de Escolta',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(18),children:[
    Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:dark,borderRadius:BorderRadius.circular(24)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Assinatura da empresa',style:TextStyle(color:Colors.white70)),SizedBox(height:6),Text('R$ 100,00 / mês',style:TextStyle(color:Colors.white,fontSize:28,fontWeight:FontWeight.w900)),SizedBox(height:6),Text('Cobrança por empresa de escolta. Não altera o preço das contratações nem a comissão de 10% do Bat Collect. Pagamento somente por PIX ou boleto.',style:TextStyle(color:Colors.white70))])),
    const SizedBox(height:12),
    Card(child:ListTile(
      leading:Icon(assinaturaAtiva?Icons.verified:Icons.lock_outline,color:assinaturaAtiva?Colors.green:Colors.red),
      title:const Text('Assinatura da empresa',style:TextStyle(fontWeight:FontWeight.w800)),
      subtitle:Text(assinaturaAtiva?'Ativa • R$ 100,00/mês':'Inativa • painel pago bloqueado'),
      trailing:FilledButton.icon(
        style:FilledButton.styleFrom(backgroundColor:orange),
        onPressed:()=>_iniciarAssinatura(c),
        icon:const Icon(Icons.pix),
        label:Text(assinaturaAtiva?'Gerenciar':'Assinar'),
      ),
    )),
    const SizedBox(height:20),const _Title('Batedores da minha empresa'),const SizedBox(height:8),
    ...batedores.map((b)=>Card(margin:const EdgeInsets.only(bottom:10),child:ListTile(leading:CircleAvatar(backgroundColor:orange.withValues(alpha:.12),child:const Icon(Icons.directions_car,color:orange)),title:Text(b['nome']!,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${b['status']} • ${b['local']}\nÚltima atualização: ${b['hora']}'),isThreeLine:true,trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const DocumentsPage())))),
    const SizedBox(height:8),const _Title('Localização dos batedores'),const SizedBox(height:8),
    Container(height:190,decoration:BoxDecoration(color:Colors.black12,borderRadius:BorderRadius.circular(20)),child:const Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.map_outlined,size:52,color:dark),SizedBox(height:8),Text('Mapa em tempo real',style:TextStyle(fontWeight:FontWeight.w900)),Text('A integração de localização/Firebase será ligada nesta etapa.',style:TextStyle(color:Colors.black54))]))),
    const SizedBox(height:20),const _Title('Histórico do batedor'),const SizedBox(height:8),
    Card(child:Column(children:[ListTile(leading:const Icon(Icons.history,color:orange),title:const Text('João da Silva'),subtitle:const Text('Arujá → Guarulhos • operação em andamento'),trailing:const Icon(Icons.chevron_right)),const Divider(height:1),ListTile(leading:const Icon(Icons.route,color:orange),title:const Text('Carlos Oliveira'),subtitle:const Text('Guarulhos → Campinas • concluída'),trailing:const Icon(Icons.chevron_right))])),
    const SizedBox(height:14),const Text('Regra de acesso: a empresa visualiza somente os batedores vinculados à própria empresa. Esta tela é a base visual; as permissões e dados reais serão aplicados pelas regras do Firebase.',style:TextStyle(color:Colors.black54)),
  ]));

  Future<void> _iniciarAssinatura(BuildContext context) async {
    await showModalBottomSheet<void>(
      context: context,
      builder: (c) => Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Assinatura da empresa', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
            const SizedBox(height: 12),
            const Text('Formas de pagamento previstas: PIX e boleto.'),
            const SizedBox(height: 8),
            const Text('A cobrança online ainda precisa ser conectada ao provedor de pagamentos no backend. Cartão de crédito não faz parte desta versão.', style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: FilledButton(style: FilledButton.styleFrom(backgroundColor: orange), onPressed: () => Navigator.pop(c), child: const Text('Entendi'))),
          ],
        ),
      ),
    );
  }
}

class AdminPage extends StatefulWidget{const AdminPage({super.key});@override State<AdminPage> createState()=>_AdminPageState();}
class _AdminPageState extends State<AdminPage>{final pending={'Batedor • João da Silva':false,'Empresa • Escolta Exemplo Ltda':false};@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Administrador',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(18),children:[const _Title('Cadastros e aprovações'),const SizedBox(height:10),...pending.entries.map((e)=>Card(margin:const EdgeInsets.only(bottom:10),child:ListTile(leading:Icon(e.value?Icons.verified:Icons.pending_actions,color:orange),title:Text(e.key,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text(e.value?'Aprovado':'Aguardando análise'),trailing:Switch(value:e.value,onChanged:(v)=>setState(()=>pending[e.key]=v)))) ,const SizedBox(height:16),const _Title('Gestão'),const SizedBox(height:8),Card(child:Column(children:[ListTile(onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const DocumentsPage())),leading:const Icon(Icons.badge_outlined,color:orange),title:const Text('Documentos e credenciais'),subtitle:const Text('CNH • PRF • veículo • empresa vinculada'),trailing:const Icon(Icons.chevron_right)),const Divider(height:1),const ListTile(leading:Icon(Icons.block,color:orange),title:Text('Bloqueios temporários'),trailing:Icon(Icons.chevron_right)),const Divider(height:1),const ListTile(leading:Icon(Icons.groups,color:orange),title:Text('Empresas e batedores'),trailing:Icon(Icons.chevron_right))])),const SizedBox(height:14),const Text('Modo de teste: as alterações desta tela ainda não são sincronizadas com o Firebase.',style:TextStyle(color:Colors.black54))]));}

class IncomingCallPage extends StatelessWidget{const IncomingCallPage({super.key});@override Widget build(BuildContext c)=>Scaffold(backgroundColor:dark,body:SafeArea(child:Padding(padding:const EdgeInsets.all(24),child:Column(children:[const Spacer(),const Icon(Icons.notifications_active,color:orange,size:70),const SizedBox(height:18),const Text('NOVA OPERAÇÃO',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:26)),const SizedBox(height:8),const Text('Arujá, SP → Campinas, SP',style:TextStyle(color:Colors.white70,fontSize:18)),const SizedBox(height:30),Row(children:[Expanded(child:OutlinedButton(style:OutlinedButton.styleFrom(foregroundColor:Colors.white,padding:const EdgeInsets.all(18)),onPressed:()=>Navigator.pop(c),child:const Text('Recusar'))),const SizedBox(width:12),Expanded(child:FilledButton(style:FilledButton.styleFrom(backgroundColor:orange,padding:const EdgeInsets.all(18)),onPressed:()=>Navigator.pop(c),child:const Text('Aceitar')))]),const Spacer(),const Text('Tela preparada para chamada destacada. O recebimento com o app em segundo plano depende da configuração do Firebase Messaging e das permissões do Android.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white54))]))));}

class SupportBotPage extends StatefulWidget{const SupportBotPage({super.key});@override State<SupportBotPage> createState()=>_SupportBotPageState();}
class _SupportBotPageState extends State<SupportBotPage>{final ctl=TextEditingController();final List<(bool,String)> msgs=[(false,'Olá! Sou o assistente automático do Bat Connect. Posso ajudar com dúvidas simples sobre chamadas, mapa, documentos, perfil, pagamentos e operações.')];String answer(String q){final x=q.toLowerCase();if(x.contains('foto')||x.contains('perfil'))return 'No Perfil, toque na câmera sobre a foto e escolha Tirar foto ou Galeria.';if(x.contains('pix')||x.contains('boleto')||x.contains('pagamento'))return 'O Bat Collect está configurado para PIX e boleto. O repasse depende da conclusão e validação da operação.';if(x.contains('mapa')||x.contains('waze'))return 'Na operação, abra Mapa e escolha Google Maps ou Waze para navegação.';if(x.contains('chamada')||x.contains('online'))return 'O batedor precisa estar Online para receber novas operações. A chamada destacada será ligada ao Firebase Messaging na integração online.';if(x.contains('document'))return 'Em Documentos ficam CNH, credencial PRF, veículo de escolta e vínculo com a empresa.';if(x.contains('sinistro'))return 'Use o atalho Sinistro para registrar acidente, avaria, pane, roubo/furto ou outra ocorrência.';return 'Essa dúvida precisa do atendimento humano. Posso registrar o assunto para o suporte quando a integração online estiver ativa.';}void send(){final q=ctl.text.trim();if(q.isEmpty)return;setState((){msgs.add((true,q));msgs.add((false,answer(q)));});ctl.clear();}@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Assistente Bat Connect',style:TextStyle(fontWeight:FontWeight.w900))),body:Column(children:[Expanded(child:ListView.builder(padding:const EdgeInsets.all(16),itemCount:msgs.length,itemBuilder:(_,i){final m=msgs[i];return Align(alignment:m.$1?Alignment.centerRight:Alignment.centerLeft,child:Container(margin:const EdgeInsets.only(bottom:8),padding:const EdgeInsets.all(12),constraints:const BoxConstraints(maxWidth:310),decoration:BoxDecoration(color:m.$1?orange:Colors.white,borderRadius:BorderRadius.circular(16)),child:Text(m.$2,style:TextStyle(color:m.$1?Colors.white:dark))));})),Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:TextField(controller:ctl,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'Digite sua dúvida'))),const SizedBox(width:8),IconButton.filled(onPressed:send,icon:const Icon(Icons.send))]))]));}


class NavigationPage extends StatefulWidget {
  const NavigationPage({super.key});
  @override State<NavigationPage> createState() => _NavigationPageState();
}

class _NavigationPageState extends State<NavigationPage> {
  static const destination = LatLng(-23.4543, -46.5337);
  LatLng? current;
  String locationStatus = 'Obtendo localização...';

  @override
  void initState() { super.initState(); _loadLocation(); }

  Future<void> _loadLocation() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      if (mounted) setState(() => locationStatus = 'Ative a localização do aparelho.');
      return;
    }
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      if (mounted) setState(() => locationStatus = 'Permissão de localização não concedida.');
      return;
    }
    final p = await Geolocator.getCurrentPosition();
    if (mounted) setState(() { current = LatLng(p.latitude, p.longitude); locationStatus = 'Localização atualizada.'; });
  }

  Future<void> _open(BuildContext context, String app) async {
    final lat = destination.latitude, lng = destination.longitude;
    final Uri uri = app == 'waze'
        ? Uri.parse('https://waze.com/ul?ll=$lat,$lng&navigate=yes')
        : Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&travelmode=driving');
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível abrir o aplicativo de navegação.')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Acompanhamento de rota', style: TextStyle(fontWeight: FontWeight.w900))),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      ClipRRect(borderRadius: BorderRadius.circular(26), child: SizedBox(height: 280, child: GoogleMap(
        initialCameraPosition: const CameraPosition(target: destination, zoom: 13),
        myLocationEnabled: current != null, myLocationButtonEnabled: true,
        markers: {const Marker(markerId: MarkerId('destino'), position: destination, infoWindow: InfoWindow(title: 'Destino da operação'))},
      ))),
      const SizedBox(height: 8), Text(locationStatus, style: const TextStyle(color: Colors.black54)),
      const SizedBox(height: 18), const _Title('Escolha como navegar'), const SizedBox(height: 10),
      SizedBox(width: double.infinity, child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: orange, padding: const EdgeInsets.all(16)), onPressed: () => _open(context, 'google'), icon: const Icon(Icons.map_outlined), label: const Text('Abrir no Google Maps'))),
      const SizedBox(height: 10),
      SizedBox(width: double.infinity, child: OutlinedButton.icon(style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(16)), onPressed: () => _open(context, 'waze'), icon: const Icon(Icons.navigation_rounded), label: const Text('Abrir no Waze'))),
      const SizedBox(height: 20),
      const Card(child: Padding(padding: EdgeInsets.all(18), child: Row(children: [Icon(Icons.gps_fixed, color: orange), SizedBox(width: 12), Expanded(child: Text('Chegada operacional: validação prevista a até 10 m do destino. Histórico de rota: registrar deslocamentos de pelo menos 50 m.'))]))),
    ]),
  );
}



class ChatPage extends StatefulWidget { const ChatPage({super.key}); @override State<ChatPage> createState()=>_ChatPageState(); }
class _ChatPageState extends State<ChatPage>{
  final controller=TextEditingController(); final List<String> messages=[];
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Chat da operação',style:TextStyle(fontWeight:FontWeight.w900))),body:Column(children:[Expanded(child:messages.isEmpty?const Center(child:Padding(padding:EdgeInsets.all(24),child:Text('Nenhuma mensagem ainda. Use o campo abaixo para testar o chat local desta demonstração.',textAlign:TextAlign.center))):ListView.builder(padding:const EdgeInsets.all(16),itemCount:messages.length,itemBuilder:(_,i)=>Align(alignment:Alignment.centerRight,child:Card(child:Padding(padding:const EdgeInsets.all(12),child:Text(messages[i]))))),Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:TextField(controller:controller,decoration:const InputDecoration(hintText:'Digite uma mensagem'))),const SizedBox(width:8),IconButton.filled(onPressed:(){final t=controller.text.trim();if(t.isNotEmpty){setState(()=>messages.add(t));controller.clear();}},icon:const Icon(Icons.send))]))]));
}

class DocumentsPage extends StatefulWidget { const DocumentsPage({super.key}); @override State<DocumentsPage> createState()=>_DocumentsPageState(); }
class _DocumentsPageState extends State<DocumentsPage>{
  final cnh=TextEditingController(),validade=TextEditingController(),prf=TextEditingController(),veiculo=TextEditingController(),empresa=TextEditingController();
  final picker=ImagePicker(); final Map<String,XFile?> anexos={'CNH':null,'Credencial PRF':null,'Veículo':null};
  @override void initState(){super.initState();_load();}
  Future<void> _load()async{final p=await SharedPreferences.getInstance();cnh.text=p.getString('doc_cnh')??'';validade.text=p.getString('doc_validade')??'';prf.text=p.getString('doc_prf')??'';veiculo.text=p.getString('doc_veiculo')??'';empresa.text=p.getString('doc_empresa')??'';if(mounted)setState((){});}
  Future<void> anexar(String tipo,ImageSource source)async{final x=await picker.pickImage(source:source,imageQuality:85,maxWidth:1800);if(x!=null)setState(()=>anexos[tipo]=x);}
  void escolherAnexo(String tipo)=>showModalBottomSheet(context:context,builder:(c)=>SafeArea(child:Wrap(children:[ListTile(leading:const Icon(Icons.camera_alt,color:orange),title:const Text('Fotografar documento'),onTap:(){Navigator.pop(c);anexar(tipo,ImageSource.camera);}),ListTile(leading:const Icon(Icons.photo_library,color:orange),title:const Text('Escolher da galeria'),onTap:(){Navigator.pop(c);anexar(tipo,ImageSource.gallery);})])));
  Widget campo(TextEditingController ctl,String label,IconData icon,{TextInputType? keyboard})=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextField(controller:ctl,keyboardType:keyboard,decoration:InputDecoration(labelText:label,prefixIcon:Icon(icon,color:orange))));
  Widget anexo(String tipo)=>Card(margin:const EdgeInsets.only(bottom:10),child:ListTile(leading:Icon(anexos[tipo]==null?Icons.attach_file:Icons.check_circle,color:orange),title:Text('Anexar $tipo',style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text(anexos[tipo]?.name??'Fotografe ou selecione uma imagem'),trailing:const Icon(Icons.upload_file),onTap:()=>escolherAnexo(tipo)));
  Future<void> salvar()async{if(cnh.text.trim().isEmpty||validade.text.trim().isEmpty||empresa.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Preencha CNH, validade e empresa vinculada.')));return;}final p=await SharedPreferences.getInstance();await p.setString('doc_cnh',cnh.text.trim());await p.setString('doc_validade',validade.text.trim());await p.setString('doc_prf',prf.text.trim());await p.setString('doc_veiculo',veiculo.text.trim());await p.setString('doc_empresa',empresa.text.trim());if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Documentos salvos neste aparelho.')));}
  @override void dispose(){for(final x in [cnh,validade,prf,veiculo,empresa]){x.dispose();}super.dispose();}
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Documentos e CNH',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(18),children:[
    const _Title('Cadastro do batedor'),const SizedBox(height:12),
    campo(cnh,'Número da CNH',Icons.credit_card,keyboard:TextInputType.number),campo(validade,'Validade da CNH (DD/MM/AAAA)',Icons.event),
    campo(prf,'Número da credencial PRF',Icons.verified_user_outlined),campo(veiculo,'Credencial do veículo de escolta',Icons.directions_car),campo(empresa,'Empresa de escolta vinculada',Icons.business),
    const SizedBox(height:4),const _Title('Anexos'),const SizedBox(height:10),anexo('CNH'),anexo('Credencial PRF'),anexo('Veículo'),const SizedBox(height:8),
    SizedBox(width:double.infinity,child:FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:orange,padding:const EdgeInsets.all(16)),onPressed:salvar,icon:const Icon(Icons.save_outlined),label:const Text('Salvar documentos'))),
    const SizedBox(height:14),const Text('Os dados digitados ficam persistidos localmente nesta build. O envio dos arquivos e a aprovação definitiva continuam dependentes da conexão com Firebase Storage/Firestore.',style:TextStyle(color:Colors.black54))
  ]));
}

class HistoryPage extends StatelessWidget { const HistoryPage({super.key}); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Histórico',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(18),children:const [_Title('Histórico de operações'),SizedBox(height:10),ListTile(leading:Icon(Icons.check_circle_outline,color:orange),title:Text('São Paulo → Arujá'),subtitle:Text('Concluída • entrega validada')),ListTile(leading:Icon(Icons.route,color:orange),title:Text('Arujá → Guarulhos'),subtitle:Text('Em andamento • rota sendo acompanhada')),SizedBox(height:12),Text('O histórico de rota online deverá registrar deslocamentos de pelo menos 50 m quando a integração de localização/Firebase estiver ativa.',style:TextStyle(color:Colors.black54))])); }

class IncidentPage extends StatefulWidget { const IncidentPage({super.key}); @override State<IncidentPage> createState()=>_IncidentPageState(); }
class _IncidentPageState extends State<IncidentPage>{String type='Acidente'; final details=TextEditingController(); bool sent=false; @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Registrar sinistro',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(18),children:[const Text('Use este registro para ocorrências ligadas à operação.',style:TextStyle(color:Colors.black54)),const SizedBox(height:14),DropdownButtonFormField<String>(initialValue:type,items:['Acidente','Avaria','Pane','Roubo/Furto','Outro'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>type=v??type),decoration:const InputDecoration(labelText:'Tipo de ocorrência')),const SizedBox(height:12),TextField(controller:details,maxLines:5,decoration:const InputDecoration(labelText:'Descrição do sinistro',alignLabelWithHint:true)),const SizedBox(height:14),FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:orange,padding:const EdgeInsets.all(16)),onPressed:()=>setState(()=>sent=true),icon:const Icon(Icons.save_outlined),label:const Text('Registrar ocorrência')),if(sent)const Padding(padding:EdgeInsets.only(top:14),child:Text('Ocorrência registrada localmente para teste. O envio ao backend/Firebase será ativado na versão integrada.',style:TextStyle(fontWeight:FontWeight.w700)))]));}}
