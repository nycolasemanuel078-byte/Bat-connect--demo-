# Bat Connect / Bat Collect — versão moderna de teste

Versão consolidada em 18/09/2026.

## Incluído
- Interface moderna Empresa/Batedor
- Online/Offline modernizado
- Ajuda e suporte com mensagens prontas
- Bat Collect somente PIX e boleto
- Regra 90% prestador / 10% plataforma
- Acesso de navegação por Google Maps e Waze
- Regras visuais de chegada a 10 m e histórico >= 50 m
- Workflow GitHub Actions para gerar APK release de teste
- Gradle Wrapper 8.14.3

## Integrações que exigem credenciais reais
Firebase/Firestore/FCM e mapa embutido com Google Maps SDK não podem ser ativados sem os arquivos/chaves do projeto (por exemplo google-services.json e chave Maps). Esta versão não inventa credenciais. Google Maps e Waze são abertos externamente e já funcionam como opção de navegação quando instalados/disponíveis no aparelho.
