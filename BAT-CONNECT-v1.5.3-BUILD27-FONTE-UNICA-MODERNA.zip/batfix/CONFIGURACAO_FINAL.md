# Bat Connect — configuração final

Esta versão contém a interface moderna, suporte com mensagens rápidas, Bat Collect apenas com PIX e boleto, logo oficial como ícone Android, Google Maps dentro do app, abertura externa no Google Maps/Waze, permissões de localização e dependências Firebase preparadas.

## Únicos dados externos que não podem ser inventados

1. `GOOGLE_MAPS_API_KEY`: criar um Secret no GitHub com esse nome. Sem uma chave válida, o APK compila, mas o mapa interno não carrega os blocos do Google Maps.
2. Firebase: adicionar o `android/app/google-services.json` do projeto Firebase real antes de ativar `Firebase.initializeApp()` e os serviços Auth/Firestore/Storage/FCM. As bibliotecas já estão declaradas no `pubspec.yaml`, mas nenhuma credencial foi inventada nesta pasta.

## Build

O workflow `.github/workflows/main.yml` usa Flutter 3.47.3, Java 17 e gera o artefato `Bat-Connect-APK`.
