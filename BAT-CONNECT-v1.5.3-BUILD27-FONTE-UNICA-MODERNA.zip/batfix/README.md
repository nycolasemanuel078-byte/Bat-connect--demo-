# Bat Connect / Bat Collect — versão moderna de teste

Versão consolidada em 18/09/2026.

## Incluído
- Interface moderna Empresa/Batedor
- Online/Offline modernizado
- Ajuda e suporte com mensagens prontas
- Bat Collect somente PIX e boleto
- Regra 90% prestador / 10% plataforma
- Acesso de navegação por Google Maps e Waze
- Regras visuais de chegada a 10 m e histórico >= 50 m
- Workflow GitHub Actions para gerar APK release de teste
- Gradle Wrapper 8.14.3

## Integrações que exigem credenciais reais
Firebase/Firestore/FCM e mapa embutido com Google Maps SDK não podem ser ativados sem os arquivos/chaves do projeto (por exemplo google-services.json e chave Maps). Esta versão não inventa credenciais. Google Maps e Waze são abertos externamente e já funcionam como opção de navegação quando instalados/disponíveis no aparelho.

## Assinatura da Empresa de Escolta
- Valor de referência mantido em R$ 100,00/mês por empresa.
- Formas de pagamento desta versão: somente PIX e boleto.
- Cartão de crédito fica para uma fase futura.
- A integração real da cobrança ainda depende da escolha/configuração do provedor de pagamentos no backend.
- A assinatura é separada da comissão de 10% do Bat Collect.
